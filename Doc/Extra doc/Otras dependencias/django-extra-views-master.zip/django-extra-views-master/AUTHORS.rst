Primary Author(s):

 * Andrew Ingram (https://github.com/AndrewIngram)

Other Contributors:

 * Sergey Fursov (https://github.com/GeyseR)
 * Pavel Zhukov (https://github.com/zeus)
 * Piet Delport (https://github.com/pjdelport)
 * jgsogo (https://github.com/jgsogo)
 * Krzysiek Szularz (https://github.com/szuliq)
 * Miguel Restrepo (https://github.com/miguelrestrepo)
 * Henry Ward (https://bitbucket.org/henward0)
